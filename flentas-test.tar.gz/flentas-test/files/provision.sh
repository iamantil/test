#!/bin/bash
echo "Hi, I don't do anything right now. I'm just an example of how to do basic provisioning with shell scripts."
service nginx stop  1>&2 > /dev/null  # I lied